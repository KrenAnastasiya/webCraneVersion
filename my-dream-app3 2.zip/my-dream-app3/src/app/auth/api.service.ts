import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { People } from './people';

@Injectable({
  providedIn: 'root'
})
export class PeopleAPI {
  API_URL = 'http://localhost:5000';
  peoples: People[]

  constructor(private httpClient: HttpClient) {}

  getPeoples() {
    return this.httpClient.get(`${this.API_URL}/api/peoples`).pipe(
      map((res) => {
      this.peoples = res['peoples'];
      return this.peoples;
    }))
  }
}