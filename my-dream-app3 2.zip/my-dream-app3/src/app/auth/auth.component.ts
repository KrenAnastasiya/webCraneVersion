import { Component, OnInit } from '@angular/core';
import { PeopleAPI } from './api.service';
import { People } from './people';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {
  title = 'frontend';
  view_password = false;
  people: People[];

  constructor(private apiService: PeopleAPI){ }

  ngOnInit(){
    this.getPeople();
  }

  public getPeople() {
    this.apiService.getPeoples().subscribe((data:People[])=>{
      this.people = data;
    });
  }

  public getIdArr(id) {
    

  }
  public sortById(id) {
    
  }

  public changeView() {
    this.view_password = !this.view_password
  }
}
