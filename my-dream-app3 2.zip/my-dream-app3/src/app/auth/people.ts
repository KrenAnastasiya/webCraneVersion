export class People {
  constructor(
    public login: string,
    public password: string
  ) {}
}
