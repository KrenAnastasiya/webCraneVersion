import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CraneComponent } from './crane/crane.component';
import { AuthComponent } from './auth/auth.component';

const routes: Routes = [
   { path: 'cranes', component: CraneComponent },
   { path: 'auth', component: AuthComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
