import { Component, OnInit } from '@angular/core';
import { CraneAPI } from './api.service';
import { Crane } from './crane';
@Component({
  selector: 'app-crane',
  templateUrl: './crane.component.html',
  styleUrls: ['./crane.component.css']
})
export class CraneComponent implements OnInit {
  current_crane = 0;
  loaded = false;
  date = "0000-00-00";
  StartDate = "0000-00-00";
  EndDate = "0000-00-00"

  crane: Crane[];
  constructor(private apiService: CraneAPI){ }

  ngOnInit(){
    this.getCranes();
  }

  public changeCrane(e, index) {
    e.preventDefault();
    this.current_crane = index;
  }

  public getCranes(){
    this.apiService.getCranes().subscribe((data:Crane[])=>{
      this.crane = data;
      this.loaded = true
    });
  }

  public getIdArr(id){
    

  }
  public sortById(id) {
    
  }

  public sortDate(StartDate, EndDate, date){
    StartDate = new Date(StartDate); 
    EndDate = new Date(EndDate); 
    date = new Date(date); 
    if((StartDate<=date)&&(date<=EndDate)){
      return true;
    }
    else{
      return false;
    }
}
  
 

}
