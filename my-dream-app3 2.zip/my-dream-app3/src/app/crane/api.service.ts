import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { Crane } from './crane';

@Injectable({
  providedIn: 'root'
})
export class CraneAPI {
  API_URL = 'http://localhost:5000';
  cranes: Crane[]

  constructor(private httpClient: HttpClient) {}

  getCranes() {
    return this.httpClient.get(`${this.API_URL}/api/cranes`).pipe(
      map((res) => {
      this.cranes = res['cranes'];
      return this.cranes;
    }))
  }
}