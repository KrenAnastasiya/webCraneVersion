export class Crane {
  constructor(
    public id: number,
    public name: string,
    public cicle: number,
    public maxSpeed: number,
    public averageSpeed: number,
    public TO: number,
    public error: Array<Error>,
  ) {}
}
export class Error{
	constructor(
		public number: number,
		public date: string,
		public text: string
	){}
}
