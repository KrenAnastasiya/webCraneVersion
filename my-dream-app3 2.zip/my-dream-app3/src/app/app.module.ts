import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { CraneComponent } from './crane/crane.component';
import { AuthComponent } from './auth/auth.component';
import { MatDividerModule, MatListModule } from '@angular/material';

@NgModule({
  declarations: [
    AppComponent,
    CraneComponent,
    AuthComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    AngularFontAwesomeModule,
    MatDividerModule,
    MatListModule
  ],
  exports: [MatDividerModule, MatListModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {

}
